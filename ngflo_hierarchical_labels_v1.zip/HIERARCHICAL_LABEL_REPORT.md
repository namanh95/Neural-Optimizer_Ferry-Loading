# Hierarchical Deck-First Labeling v1

The first symmetry-aware response is to replace aggressive exact-lane pruning with a hierarchical
candidate policy:

1. predict promising deck(s) for each vehicle;
2. retain **all compatible lanes** on every selected deck;
3. let the exact reduced MIP choose the lane and ordered slot.

This avoids treating one arbitrary lane in a symmetric/near-symmetric deck as the only correct target.

Dataset statistics:
{
  "edge_rows": 11248,
  "vehicle_deck_rows": 1406,
  "vehicles": 810,
  "mean_compatible_decks_per_vehicle": 1.7358024691358025,
  "mean_compatible_lanes_on_gold_deck": 8.0
}

Held-out deck-scorer performance:
 top_decks  deck_recall  mean_fraction_candidate_decks_retained  n_vehicles
         1     0.740741                                 0.62963         270
         2     1.000000                                 1.00000         270
         3     1.000000                                 1.00000         270

Top-1 deck selection recovers the certified optimal deck for 74.1%
of held-out vehicles. Top-2 reaches 100%, but because the current synthetic heavy-vehicle compatibility
often exposes only one or two decks, Top-2 retains essentially the full deck candidate set.

Conclusion: hierarchical deck-first pruning is safer and better aligned with solution non-uniqueness,
but the present three-deck synthetic ferry does not yet offer enough deck-level branching to create
large compression. The stronger next experiment should therefore use the hierarchical labels to
restrict lane groups conservatively, and evaluate objective loss directly in a reduced MIP rather
than judging success only by exact assignment classification.
