# NGFLO Hardness Predictor and Solver Router v1

## Objective

The router decides, before solving, whether a ferry-loading state should be sent to:
- **Full-MIP** when the state appears easy; or
- **Adaptive-NGFLO** when the state appears hard.

The predictor uses only pre-solve instance features. It does not require the optimal objective,
MIP gap, or solver runtime at deployment time.

## Hardness definition used for training

An instance is labeled hard when a 1-second unrestricted Full-MIP diagnostic run either:
1. fails to reach a MIP gap of 1e-4 or better; or
2. consumes at least 90% of the one-second time budget.

The dataset contains 48 synthetic instances:
4 sizes (20, 30, 40, 50) x 3 fleet regimes x 4 random seeds.

Seed 33 is held out completely for testing.

## Held-out performance

- Test instances: 12
- Hard-state prevalence: 16.7%
- Accuracy: 91.7%
- Balanced accuracy: 95.0%
- Hard-state precision: 66.7%
- **Hard-state recall: 100.0%**
- F1 for hard states: 0.800
- ROC-AUC: 0.950

Confusion matrix (rows=true, columns=predicted):
[[9, 1], [0, 2]]

The selected probability threshold is 0.40. It intentionally prioritizes recall of hard instances,
because misrouting a difficult state to Full-MIP is more costly than occasionally sending an easy
state to adaptive NGFLO.

## Held-out n=50 routing

            instance_id  hard_probability  hard_label  predicted_hard          route  routed_runtime_s  full_5s_runtime_s  runtime_saving_vs_full_pct  objective_change_vs_full_pct  routed_loaded
 small_balanced_n50_s33          0.771737           1               1 Adaptive-NGFLO          0.353654           3.557509                   90.058937                      3.536042             50
    small_heavy_n50_s33          0.993132           1               1 Adaptive-NGFLO          6.081353           5.029130                  -20.922569                      0.000610             48
small_car_dense_n50_s33          0.081117           0               0       Full-MIP          0.286936           0.286936                    0.000000                      0.000000             50

For the three n=50 seed-33 cases, the router makes the desired qualitative distinction:
- balanced -> Adaptive-NGFLO;
- heavy -> Adaptive-NGFLO;
- car-dense -> Full-MIP.

This avoids the previously observed car-dense failure, where adaptive NGFLO was slower and worse
than a trivially easy Full-MIP.

The heavy case remains a stress regime: routing correctly identifies it as hard, but the current
adaptive candidate scorer still reaches K=12 and defers vehicles. Correct routing therefore does not
eliminate the need for a full-search fallback.

## Interpretation of learned hardness

The strongest positive standardized coefficients are associated with:
- number of vehicles;
- total vehicle length / length pressure;
- total mass / mass pressure;
- maximum vehicle height.

This is operationally sensible: larger and more capacity-intensive states are more likely to produce
difficult branch-and-bound search.

## Recommended final routing logic

1. Compute pre-solve hardness probability p_h.
2. If p_h < 0.40, solve Full-MIP directly.
3. If p_h >= 0.40, run adaptive NGFLO with K=6 -> 8 -> 12.
4. If K=12 still causes deferral or other failure indicators, expand to the full candidate set and
   continue as Full-MIP using the best NGFLO incumbent as a warm start.

The fourth step is essential for preserving robustness in the heavy-vehicle stress regime.
