# Hard-Residual Dynamic Stress Experiment v1

## Why this experiment was needed

The ordinary commitment-aware rolling-horizon experiments produced very small residual MIPs.
Consequently, Full-MIP was already easy and the neural restriction layer had little opportunity
to create computational gains.

This stress experiment deliberately delays the commitment boundary:
- no physical commitments in the first two decision epochs;
- later commitments remain lane-prefix consistent;
- Poisson arrival intensity is increased to 1.6 times the base rate;
- horizon = 4;
- paired stochastic path seed = 101;
- balanced and heavy fleets are evaluated.

Arrival and cancellation random-number streams are separated, so Full-MIP and NGFLO receive
the same exogenous stochastic realization.

## Equal-compute comparison

A second Full-MIP benchmark was rerun with a 2.5-second per-epoch solver allowance, approximately
matching the maximum cumulative budget available to the adaptive NGFLO path. This removes the main
compute-budget confound from the first stress run.

congestion  total_arrivals  total_cancellations  final_loaded_full_equal  final_loaded_ngflo  final_deferred_full_equal  final_deferred_ngflo  cumulative_wait_units_full_equal  cumulative_wait_units_ngflo  total_runtime_s_full_equal  total_runtime_s_ngflo  runtime_change_pct  wait_change_pct
  balanced              77                    3                       74                  74                          0                     0                             207.0                        192.0                    3.983570               1.084762          -72.769094        -7.246377
     heavy              77                    3                       67                  67                          7                     7                             206.0                        212.0                    6.249923               6.502788            4.045888         2.912621

## Router activation

congestion  seed  epochs  adaptive_epochs  full_mip_epochs  max_hard_probability  mean_hard_probability  max_waiting_after_commit
  balanced   101       4                2                2              0.840906               0.384795                        36
     heavy   101       4                2                2              0.997729               0.572297                        36

## Feasibility

{
  "ngflo_stress_max_capacity_violation": 0.0,
  "equal_full_max_capacity_violation": 0.0,
  "max_discharge_inversions": 0,
  "max_duplicate_slots": 0,
  "max_transverse_violation": 0.0,
  "all_feasible": true
}

## Balanced hard-residual state

Both controllers load all 74 non-cancelled vehicles with zero final deferral.

Equal-budget Full-MIP runtime:
3.984 s.

NGFLO runtime:
1.085 s.

Therefore NGFLO reduces runtime by approximately
72.8% while preserving the same
final loaded count and feasibility.

Cumulative waiting also falls from
207
to
192
vehicle-epoch units.

This is the first commitment-aware dynamic state in which neural restriction produces a substantial
computational gain under approximately matched solver budgets.

## Heavy hard-residual state

Under the equal-budget comparison, both controllers load 67 vehicles and defer 7.

Full-MIP runtime:
6.250 s.

NGFLO runtime:
6.503 s.

NGFLO is therefore about
4.0% slower and produces slightly more
cumulative waiting in this heavy stress state. A fallback is invoked, which confirms that the heavy
fleet remains the principal difficult regime for the current scorer.

## Scientific interpretation

The experiment supports a state-dependent dynamic claim rather than universal dominance:

- when the residual rolling-horizon state becomes hard but structurally balanced, neural candidate
  restriction can materially reduce computation while preserving final loading quality;
- in heavy-vehicle residual states, the present scorer may require fallback and can lose the speed
  advantage;
- the hardness router correctly activates adaptive NGFLO in the difficult late states of both stress paths.

This result is consistent with the static experiments and gives a clearer operational role to the
hardness router: NGFLO is an acceleration mechanism for selected hard states, not a replacement for
Full-MIP in every epoch.

## Status

This is still a focused stress experiment with one paired seed, so it should not yet be used as a
standalone statistical headline in the manuscript. It is, however, strong evidence for the design
of the final stress-test subsection.

The next logical step is to replicate this exact delayed-commitment stress design over additional
seeds, keeping the corrected paired RNG streams and equal solver-budget comparison.
