# Robust NGFLO Full-Search Fallback v1

## Implementation

The static solver-routing pipeline is now:

1. estimate pre-solve hardness;
2. easy instance -> Full-MIP;
3. hard instance -> adaptive NGFLO with K = 6 -> 8 -> 12;
4. if the adaptive solution still triggers the fallback condition, restore the full candidate set;
5. solve the full MIP with the feasible NGFLO incumbent objective imposed as an upper cutoff.

### Important solver detail

The current implementation uses `scipy.optimize.milp`. Its interface does not expose a MIP-start
vector. Therefore this experiment **does not claim a true warm start**. Instead it uses the safe
incumbent cutoff

    c^T x <= J_NGFLO,

where J_NGFLO is the objective of an already feasible adaptive solution.

Because the NGFLO incumbent itself satisfies this inequality, the cutoff cannot exclude all known
feasible solutions. A future solver with explicit MIP-start support can additionally accept the full
NGFLO incumbent vector.

## n=50 outcomes

congestion  n  seed  hard_probability                                 route  fallback_used  final_runtime_s  final_objective  final_loaded  final_deferred  final_mip_gap  full_reference_runtime_s  full_reference_objective  full_reference_mip_gap  adaptive_runtime_s  fallback_runtime_s  incumbent_before_fallback  objective_change_vs_full_pct  runtime_change_vs_full_pct
  balanced 50    33          0.771737                        Adaptive-NGFLO          False         0.356255         8.102430            50               0        0.00000                  3.588209                  7.825710            1.570092e-07            0.356255            0.000000                   8.102430                      3.536042                  -90.071499
     heavy 50    33          0.993132 Adaptive-NGFLO + Full-Search Fallback           True        13.260139       280.915872            48               2        0.00001                  5.036652                280.914158            5.214421e-02            6.090380            7.169758                 280.915872                      0.000610                  163.272870
 car_dense 50    33          0.081117                              Full-MIP          False         0.285205         7.933487            50               0        0.00000                  0.285205                  7.933487            0.000000e+00            0.000000            0.000000                        NaN                           NaN                         NaN

## Balanced case

The hardness router selects adaptive NGFLO. The algorithm terminates at K=8 without fallback.
It loads all 50 vehicles in 0.356 s,
versus 3.588 s for the reference
Full-MIP run. The runtime reduction is approximately
90.1%, at a
3.54% objective premium.

## Car-dense case

The hardness router selects Full-MIP directly. This preserves the exact solution and avoids the
unnecessary neural restriction observed previously.

## Heavy case

The router identifies the state as hard, adaptive NGFLO expands to K=12, and the full-search fallback
is invoked.

The adaptive incumbent objective before fallback is
280.915872.
After restoring the full variable set and imposing the incumbent cutoff, the best objective remains
280.915872, with two deferred vehicles.

Crucially, the fallback reduces the reported full-search MIP gap to approximately
0.0010%,
whereas the separate unrestricted five-second reference run ended with a gap of
5.21%.

This changes the interpretation of the two deferrals. They are no longer good evidence that neural
pruning alone caused the failure: after the full candidate set is restored, essentially the same
incumbent remains and the solver produces a much tighter certificate. The heavy synthetic manifest
may simply require deferral under the present ferry capacities and constraints.

The fallback is expensive in wall-clock time, however, so it should be treated as a safety/certification
mechanism rather than the normal operating route.

## Static architecture after this stage

The static NGFLO pipeline is now computationally complete at prototype level:

    state
      -> hardness router
      -> Full-MIP, if easy
      -> adaptive neural candidate restriction, if hard
      -> K=6 -> 8 -> 12
      -> full-search incumbent-cutoff fallback when required.

This architecture preserves exact feasibility because every accepted loading plan is produced by a
MIP containing the original hard constraints. Neural guidance changes the candidate set or routing
decision; it never relaxes those constraints.

## Next stage

The next major experiment should move from independent static manifests to stochastic arrivals and
rolling-horizon re-optimization. The fallback logic can then be retained as the terminal safety layer
at each decision epoch.
