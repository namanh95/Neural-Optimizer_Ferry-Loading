# Replicated Hard-Residual Dynamic Stress Experiment v1

## Design

The delayed-commitment hard-residual experiment has now been replicated over three stochastic seeds:
101, 202, and 303.

Stress configuration:
- Poisson arrivals at 1.6 times the base rate;
- no physical commitment during the first two epochs;
- lane-prefix commitment thereafter;
- four decision epochs;
- balanced and heavy fleet regimes;
- separated arrival and cancellation RNG streams;
- commitment-aware Full-MIP and hardness-routed NGFLO.

The comparison uses a longer Full-MIP allowance (2.5 s per epoch) than the ordinary rolling-horizon
benchmark to avoid the earlier under-budget confound. NGFLO retains its actual routed/adaptive stopping
rules, so this is not a literal identical wall-clock allocation at every epoch; it is a more conservative
Full-MIP reference.

## Feasibility

{
  "pairs": 6,
  "ngflo_max_capacity_violation": 0.0,
  "full_max_capacity_violation": 0.0,
  "max_discharge_inversions": 0,
  "max_duplicate_slots": 0,
  "max_transverse_violation": 0.0,
  "all_feasible": true
}

Every compared final plan is feasible under the modeled capacity, discharge-order, slot-uniqueness,
and transverse-balance constraints.

## Pairwise results

congestion  seed  final_loaded_full  final_loaded_ngflo  final_deferred_full  final_deferred_ngflo  cumulative_wait_units_full  cumulative_wait_units_ngflo  total_runtime_s_full  total_runtime_s_ngflo  runtime_saving_pct
  balanced   101                 74                  74                    0                     0                       207.0                        192.0              3.983570               1.084762           72.769094
     heavy   101                 67                  67                    7                     7                       206.0                        212.0              6.249923               6.502788           -4.045888
  balanced   202                 42                  42                    0                     0                        96.0                         96.0              0.553284               0.538713            2.633395
     heavy   202                 42                  42                    0                     0                        88.0                         93.0              2.845074               1.088312           61.747495
  balanced   303                 51                  51                    0                     0                       113.0                        119.0              1.993460               1.372520           31.148891
     heavy   303                 47                  47                    4                     4                       119.0                        119.0              4.022333               4.033816           -0.285478

## Aggregate results across three seeds

congestion  seeds  full_loaded_mean  ngflo_loaded_mean  loaded_diff_mean  full_deferred_mean  ngflo_deferred_mean  deferred_diff_mean  full_wait_mean  ngflo_wait_mean  wait_diff_mean  full_runtime_mean  ngflo_runtime_mean  runtime_saving_pct_mean  runtime_saving_pct_median
  balanced      3         55.666667          55.666667               0.0            0.000000             0.000000                 0.0      138.666667       135.666667       -3.000000           2.176771            0.998665                35.517127                  31.148891
     heavy      3         52.000000          52.000000               0.0            3.666667             3.666667                 0.0      137.666667       141.333333        3.666667           4.372443            3.874972                19.138709                  -0.285478

## Operational quality counts

congestion  pairs  same_loaded  same_deferred  ngflo_lower_wait  same_wait  ngflo_higher_wait  ngflo_faster
  balanced      3            3              3                 1          1                  1             3
     heavy      3            3              3                 0          1                  2             1

## Router activation

congestion  seeds  adaptive_epochs_mean  adaptive_epochs_total  max_hard_probability  mean_hard_probability
  balanced      3              1.000000                      3              0.840906               0.199401
     heavy      3              1.333333                      4              0.997729               0.333885

## Balanced residual states

Across all three balanced stress paths:
- NGFLO matches Full-MIP in final loaded vehicles on 3/3 paths;
- NGFLO matches Full-MIP in final deferrals on 3/3 paths;
- NGFLO is faster on 3/3 paths.

The mean runtime reduction is
35.5%,
with a median reduction of
31.1%.

Mean cumulative waiting is slightly lower under NGFLO:
138.7
versus
135.7
vehicle-epoch units.

The balanced result therefore survives replication: when commitment is deliberately delayed enough
to preserve a hard residual state, selective neural restriction can materially reduce computation
without changing final loading or deferral outcomes.

## Heavy residual states

Across all three heavy paths:
- final loaded vehicles match on 3/3 paths;
- final deferrals match on 3/3 paths;
- runtime performance is mixed.

The mean runtime reduction is
19.1%,
but the median is
-0.3%,
showing that the positive mean is driven by one favorable seed rather than consistent dominance.

Heavy-state waiting is also slightly worse on average under NGFLO:
141.3
versus
137.7
vehicle-epoch units.

This confirms that the heavy regime remains the main stress/fallback case for the current neural scorer.

## Scientific conclusion

The replicated stress experiment supports a state-dependent claim:

> Under delayed commitment, NGFLO consistently accelerates balanced hard-residual states while preserving
> final loading and deferral outcomes. Heavy-vehicle residual states are less predictable and may require
> fallback, so universal speed dominance is not supported.

This is materially stronger than the one-seed pilot because the balanced acceleration result persists
over all three tested stochastic realizations.

## Manuscript status

These three-seed stress results are suitable for inclusion as a focused robustness/stress subsection,
provided they are described as a replicated synthetic stress test rather than a definitive statistical
benchmark.

For the final paper, a larger replication set (e.g. 10+ seeds) would strengthen confidence intervals,
but the present result is already sufficient to justify the architecture and to motivate the claim that
NGFLO's computational benefit appears specifically in hard residual states.
