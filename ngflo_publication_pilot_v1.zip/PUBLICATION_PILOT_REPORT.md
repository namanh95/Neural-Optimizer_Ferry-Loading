# NGFLO Publication Experiment — Replicated Medium-Intensity Tranche v1

## Design

This is the first replicated publication-oriented experiment using the commitment-aware
rolling-horizon architecture.

Design:
- arrival process: Poisson;
- arrival intensity: medium, scale = 1.0;
- fleet compositions: balanced, heavy, car-dense;
- stochastic seeds: 101, 202, 303;
- controllers: commitment-aware Full-MIP and commitment-aware NGFLO;
- horizon: 4 decision epochs;
- paired comparison: both controllers receive the same realization for each seed/regime pair.

This produces 18 episodes and 9 paired controller comparisons.

## Feasibility certification

{
  "episodes": 18,
  "pairs": 9,
  "max_capacity_violation": 0.0,
  "max_discharge_inversions": 0,
  "max_duplicate_slots": 0,
  "max_transverse_violation": 0.0,
  "all_feasible": true
}

Every final plan satisfies the modeled capacity, transverse-balance, unique-slot, and discharge-order constraints.

## Aggregate paired results

intensity  arrival_scale congestion  pairs  loaded_diff_mean  loaded_diff_min  deferred_diff_mean  wait_diff_mean  runtime_change_pct_mean  runtime_change_pct_median  score_change_pct_mean  score_change_pct_median  full_runtime_mean  ngflo_runtime_mean  full_loaded_mean  ngflo_loaded_mean  full_deferred_mean  ngflo_deferred_mean  full_wait_mean  ngflo_wait_mean  ngflo_fallback_mean
   medium            1.0   balanced      3               0.0              0.0                 0.0             0.0                -0.170995                  -0.574897               0.005956                -0.000159           0.628034            0.626333         33.333333          33.333333            0.666667             0.666667        1.333333         1.333333                  0.0
   medium            1.0  car_dense      3               0.0              0.0                 0.0             0.0                 0.241338                   1.426818              -0.231368                 0.008699           0.448650            0.449671         34.000000          34.000000            0.000000             0.000000        0.333333         0.333333                  0.0
   medium            1.0      heavy      3               0.0              0.0                 0.0             0.0                 0.093739                   0.100927              -0.000657                 0.000234           0.300660            0.299665         33.000000          33.000000            0.333333             0.333333        3.333333         3.333333                  0.0

## Principal findings

### Loading outcomes

Across all 9 paired stochastic scenarios:
- mean loaded-vehicle difference (NGFLO minus Full-MIP) = 0 in every fleet regime;
- mean deferred-vehicle difference = 0 in every fleet regime;
- cumulative-wait difference = 0 in every fleet regime.

Thus, in this replicated medium-intensity tranche, NGFLO exactly reproduces Full-MIP's operational
loading, deferral, and waiting outcomes at the aggregate paired level.

### Runtime

Balanced fleet:
- Full-MIP mean runtime = 0.628 s;
- NGFLO mean runtime = 0.626 s;
- mean runtime change = -0.17%.

Heavy fleet:
- Full-MIP mean runtime = 0.301 s;
- NGFLO mean runtime = 0.300 s;
- mean runtime change = +0.09%.

Car-dense fleet:
- Full-MIP mean runtime = 0.449 s;
- NGFLO mean runtime = 0.450 s;
- mean runtime change = +0.24%.

At this medium intensity and short horizon, runtime differences are therefore negligible.
This is consistent with the earlier hardness-routing result: most commitment-aware residual subproblems
are easy enough that the neural restriction layer is not expected to dominate Full-MIP.

## Scientific interpretation

The key value of this tranche is **equivalence of operational outcomes under replication**, not speedup.

The replicated experiment supports the statement that, under medium Poisson arrival intensity in the
current synthetic small-ferry benchmark, commitment-aware NGFLO preserves the same loaded counts,
deferral counts, cumulative waiting, and modeled feasibility as Full-MIP across all nine paired paths.

It does **not** yet support a general runtime superiority claim. The next tranche must add low and high
arrival intensity. The high-intensity regime is particularly important because that is where hardness
routing and candidate restriction should become operationally relevant.

## Status

This tranche is publication-quality in structure but not yet sufficient in statistical scale for the
final manuscript. It should be treated as the first replicated block of the full computational design.

The next experiment should retain the same three seeds and run:
- low arrival intensity, scale = 0.6;
- high arrival intensity, scale = 1.4.

After that, the three-intensity results can be combined into the first complete dynamic comparison table.
