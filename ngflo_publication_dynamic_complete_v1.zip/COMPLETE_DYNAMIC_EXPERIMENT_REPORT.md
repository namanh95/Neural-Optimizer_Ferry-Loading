# Complete Three-Intensity Dynamic Publication Experiment v1

## Experimental design

The first complete commitment-aware dynamic comparison now spans:

- arrival process: Poisson;
- arrival intensity: low (0.6), medium (1.0), and high (1.4) relative to the base rate;
- fleet composition: balanced, heavy, and car-dense;
- stochastic seeds: 101, 202, and 303;
- controllers: commitment-aware Full-MIP and commitment-aware NGFLO;
- horizon: four rolling decision epochs.

This yields:
- 54 controller episodes;
- 27 paired Full-MIP vs NGFLO stochastic comparisons.

Each pair receives the same arrival realization, vehicle mix, and commitment process.

## Feasibility certification

{
  "episodes": 54,
  "paired_comparisons": 27,
  "max_capacity_violation": 0.0,
  "max_discharge_inversions": 0,
  "max_duplicate_slots": 0,
  "max_transverse_violation": 0.0,
  "all_feasible": true
}

All 54 final committed plans satisfy the modeled capacity constraints, transverse-balance envelope,
ordered discharge condition, and unique-slot requirement.

## Operational equivalence

Across the 27 paired stochastic comparisons:

- identical final loaded counts: 27/27;
- identical final deferral counts: 27/27;
- identical cumulative waiting: 27/27.

Thus, over all tested low, medium, and high arrival intensities, commitment-aware NGFLO reproduces the
operational outcomes of commitment-aware Full-MIP exactly on every paired stochastic path.

## Complete dynamic comparison table

intensity congestion  pairs  full_loaded_mean  ngflo_loaded_mean  full_deferred_mean  ngflo_deferred_mean  full_wait_mean  ngflo_wait_mean  full_runtime_mean  ngflo_runtime_mean  runtime_change_pct_mean
      low   balanced      3         19.333333          19.333333            0.000000             0.000000        0.000000         0.000000           0.207852            0.206906                -0.649128
      low  car_dense      3         19.333333          19.333333            0.000000             0.000000        0.000000         0.000000           0.239776            0.240084                 0.059303
      low      heavy      3         19.000000          19.000000            0.000000             0.000000        0.333333         0.333333           0.198773            0.200187                 0.985518
   medium   balanced      3         33.333333          33.333333            0.666667             0.666667        1.333333         1.333333           0.628034            0.626333                -0.170995
   medium  car_dense      3         34.000000          34.000000            0.000000             0.000000        0.333333         0.333333           0.448650            0.449671                 0.241338
   medium      heavy      3         33.000000          33.000000            0.333333             0.333333        3.333333         3.333333           0.300660            0.299665                 0.093739
     high   balanced      3         47.000000          47.000000            0.333333             0.333333        2.666667         2.666667           0.304853            0.306782                 0.540224
     high  car_dense      3         47.333333          47.333333            0.000000             0.000000        2.666667         2.666667           0.296246            0.303435                 2.079819
     high      heavy      3         42.000000          42.000000            0.666667             0.666667        6.000000         6.000000           0.339977            0.339532                -0.197295

## Runtime interpretation

intensity  mean_runtime_change_pct  median_runtime_change_pct  mean_loaded_difference  mean_deferred_difference  mean_wait_difference
     high                 0.807583                   0.525869                     0.0                       0.0                   0.0
      low                 0.131898                   0.236733                     0.0                       0.0                   0.0
   medium                 0.054694                   0.100927                     0.0                       0.0                   0.0

The runtime differences remain small across the three intensity levels. High arrival intensity does
not automatically produce a large NGFLO speedup in the commitment-aware model because each rolling
subproblem contains only the *currently uncommitted residual suffix*. Commitment continuously removes
vehicles from the decision set, so even a high total arrival count can leave a relatively small
residual MIP at each epoch.

This is an important structural result. It means that the strong static n=50 speed advantage should
not be transferred automatically to a commitment-aware dynamic setting.

## What can now be stated safely

The current synthetic evidence supports the following claim:

"Across 27 paired stochastic rolling-horizon scenarios spanning three arrival intensities and three
fleet compositions, the commitment-aware NGFLO controller matched Full-MIP in final loaded vehicles,
deferrals, cumulative waiting, and modeled feasibility. Computational differences were small because
commitment reduced the residual decision dimension at each epoch."

The evidence does **not** yet support a general claim that NGFLO is faster than rolling-horizon Full-MIP.

## Implication for Section 6

This three-intensity experiment can now populate the first complete dynamic comparison table and two
figures:
- dynamic controller comparison table;
- mean runtime comparison by intensity/fleet regime;
- final loaded-vehicle comparison.

However, because there are only three seeds per cell, the results should still be described as a
replicated synthetic experiment rather than a definitive statistical benchmark.

## Recommended next experiment

The next computational stage should target **hard dynamic residual states**, not merely increase the
number of arrival paths.

Two useful stress mechanisms are:
1. delay the commitment boundary so that more vehicles remain jointly optimizable at each epoch; or
2. use a larger ferry / larger manifest so that the residual problem itself remains difficult after
   commitment.

That experiment is the appropriate place to test whether neural candidate restriction yields dynamic
speed gains while preserving the operational-equivalence result established here.
