# Dynamic Rolling-Horizon NGFLO Prototype v1

## What was implemented

The static NGFLO architecture has now been embedded in a stochastic multi-epoch environment with:
- Poisson arrivals;
- nonhomogeneous Poisson arrivals;
- bursty arrivals;
- random cancellations;
- persistent waiting vehicles;
- repeated optimization at each decision epoch;
- Full-MIP and hardness-routed NGFLO controllers;
- adaptive K and full-search fallback retained inside the NGFLO controller.

This first pilot uses a four-epoch horizon, seed 101, and balanced/heavy vehicle mixtures.

## Important modeling limitation

This version is a **planning-state rolling horizon**, not yet a physical commitment model.

At each epoch the controller re-optimizes the complete currently available manifest. Previously planned
vehicle placements are allowed to change. Therefore `rehandles` currently measures plan churn between
successive optimization states rather than literal physical vehicle relocation on deck.

This pilot validates the stochastic computational pipeline. It should not yet be described in the
manuscript as the final operational rolling-horizon experiment.

## Paired pilot results

arrival_regime congestion  seed  total_runtime_s_full  total_runtime_s_ngflo  runtime_ratio_ngflo_full  dynamic_score_full  dynamic_score_ngflo  score_change_pct  final_loaded_full  final_loaded_ngflo  final_deferred_full  final_deferred_ngflo  fallback_count_ngflo  runtime_change_pct
        bursty   balanced   101              0.486261               0.508201                  1.045120           11.180610            11.180610          0.000000               36.0                36.0                  0.0                   0.0                   0.0            4.511981
        bursty      heavy   101              0.678915               0.480879                  0.708305           11.091912            11.140392          0.437077               36.0                36.0                  0.0                   0.0                   0.0          -29.169529
nonhomogeneous   balanced   101              0.375518               0.379357                  1.010223            9.643028             9.643028          0.000000               31.0                31.0                  0.0                   0.0                   0.0            1.022313
nonhomogeneous      heavy   101              0.328384               0.325704                  0.991838            9.587298             9.587298          0.000000               31.0                31.0                  0.0                   0.0                   0.0           -0.816156
       poisson   balanced   101              1.302545               1.235752                  0.948721           14.991371            15.083201          0.612553               48.0                48.0                  0.0                   0.0                   0.0           -5.127884
       poisson      heavy   101              1.652005               3.771402                  2.282924           14.981706           153.335731        923.486447               48.0                47.0                  0.0                   1.0                   1.0          128.292428

## Main observations

### Low-to-moderate states
For nonhomogeneous arrivals, both controllers produce identical dynamic scores and final loading counts.
Runtime is also essentially identical because the hardness router generally sends these states to
Full-MIP.

For bursty balanced traffic, Full-MIP and NGFLO again return the same dynamic score, with negligible
runtime difference.

For bursty heavy traffic, NGFLO loads the same 36 vehicles and has nearly the same score, while its
total runtime is lower in this pilot.

### Higher-pressure Poisson states
The balanced Poisson path ends with 48 vehicles and no deferrals under both controllers. NGFLO is
slightly faster, but its final planning objective is marginally worse.

The heavy Poisson path is the critical stress case. Full-MIP loads all 48 waiting vehicles, whereas
NGFLO ends with 47 loaded and one deferred vehicle after invoking fallback once. The corresponding
dynamic score becomes much worse because the current objective heavily penalizes deferral.

This indicates that the current short fallback time budget is insufficient for high-pressure dynamic
heavy-vehicle states. It is not evidence that the overall NGFLO architecture is invalid; rather, the
dynamic controller needs a stronger terminal fallback and a commitment-aware state representation.

## What this stage establishes

The stochastic pipeline itself is operational:
    arrivals/cancellations
      -> waiting pool
      -> hardness routing
      -> Full-MIP or adaptive NGFLO
      -> epoch solution
      -> next stochastic state.

The experiment also identifies the next mathematical/computational refinement clearly:
**freeze committed vehicle placements across epochs.**

Without commitment constraints, plan churn can be large and dynamic performance does not yet represent
true ferry operations.

## Next stage

The next implementation should introduce a commit set:
- positions of committed vehicles become fixed in later epochs;
- only newly arrived/uncommitted vehicles can be reassigned;
- residual lane length, residual lane mass, and residual deck mass become state variables;
- cancellation only removes vehicles that have not yet crossed the commitment boundary;
- plan churn is then replaced by a physically meaningful rehandling/relocation measure.

After this commitment-aware environment is stable, the experiment should be rerun over multiple seeds
and longer horizons before Section 6 placeholders are replaced by publication tables.
