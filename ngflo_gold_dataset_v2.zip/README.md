# NGFLO Gold Dataset v2

Expanded certified supervised dataset for neural-guided ferry loading.

## Scope
- Synthetic small ferry
- Fleet regimes: balanced, heavy, car-dense
- Vehicle counts: n = 20, 30, 40
- Seeds: 11, 22, 33
- Instances: 27
- Vehicle nodes: 810
- Position nodes: 432
- Compatibility edges: 11248
- Positive assignment edges: 810
- Exact slot assignments: 810

## Certification
Every included instance has:
- reported MIP gap = 0;
- zero discharge-order inversions;
- max constraint residual <= 1.747e-12.

## Split
- train: 9
- validation: 9
- test: 9

Each split contains all three fleet-composition regimes and all three sizes.
