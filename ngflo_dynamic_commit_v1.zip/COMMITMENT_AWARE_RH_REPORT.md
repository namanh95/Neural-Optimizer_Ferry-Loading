# Commitment-Aware Rolling-Horizon NGFLO v1

## Main refinement

The dynamic model now contains a true commitment state.

Once a vehicle is committed, its lane/deck position is preserved at every later epoch.
Newly arriving and still-uncommitted vehicles are optimized only against residual vessel capacity.

The dynamic state therefore has the operational structure

    s_t = (C_t, U_t, L_res,t, M_res,t, deck_res,t, balance_res,t),

where:
- C_t is the committed set;
- U_t is the uncommitted waiting set;
- residual capacity quantities are induced by the fixed committed prefix.

Commitment is lane-prefix based. This is important: an arbitrary interior vehicle is never frozen
while a ramp-side predecessor remains movable. Each lane therefore retains a physically consistent
front-to-back committed sequence.

## Residual constraints

At each epoch, the residual MIP enforces:
- residual lane length;
- residual lane mass;
- residual deck mass;
- transverse-balance residual capacity;
- compatibility restrictions;
- ordered discharge sequencing among new assignments;
- a discharge-order bridge between each committed lane prefix and its newly appended suffix.

Cancellations affect only vehicles that have not crossed the commitment boundary.

## Pilot design

The pilot contains:
- 3 arrival regimes: Poisson, nonhomogeneous, bursty;
- 2 fleet regimes: balanced and heavy;
- Full-MIP and hardness-routed NGFLO controllers;
- 4 decision epochs;
- paired stochastic path with seed 101.

This is still a pilot, not the final multi-seed publication experiment.

## Feasibility audit

{
  "episodes": 12,
  "max_capacity_violation": 0.0,
  "max_discharge_inversions": 0,
  "max_duplicate_slots": 0,
  "max_transverse_violation": 0.0,
  "all_feasible": true
}

Every final committed plan in the pilot satisfies the modeled lane/deck capacity constraints,
transverse-balance envelope, discharge ordering, and unique-slot requirements.

## Paired outcomes

arrival_regime congestion  seed  final_loaded_full  final_loaded_ngflo  final_deferred_full  final_deferred_ngflo  cumulative_wait_units_full  cumulative_wait_units_ngflo  total_runtime_s_full  total_runtime_s_ngflo  runtime_change_pct  score_change_pct
        bursty   balanced   101               38.0                38.0                  0.0                   0.0                         1.0                          1.0              0.413783               0.424546            2.601021          0.026631
        bursty      heavy   101               38.0                38.0                  0.0                   0.0                         8.0                          8.0              0.416967               0.416342           -0.149846         -0.000195
nonhomogeneous   balanced   101               35.0                35.0                  0.0                   0.0                         0.0                          0.0              0.471885               0.484638            2.702514          2.702514
nonhomogeneous      heavy   101               34.0                34.0                  1.0                   1.0                         1.0                          1.0              0.385503               0.406675            5.492042          0.000868
       poisson   balanced   101               41.0                41.0                  0.0                   0.0                         1.0                          1.0              0.562444               0.527780           -6.163081         -0.085458
       poisson      heavy   101               40.0                40.0                  0.0                   0.0                         8.0                          8.0              0.417922               0.419671            0.418613          0.000546

## Interpretation

The commitment-aware formulation removes the major artifact found in the previous rolling-horizon
prototype. Re-optimization no longer moves already committed vehicles, so plan churn is no longer
used as a proxy for physical rehandling.

Across the six paired stochastic scenarios, Full-MIP and NGFLO produce exactly the same final loading
and deferral counts. Their cumulative waiting outcomes are also identical on every tested path.

Runtime differences are small at this scale. The largest favorable NGFLO difference appears in the
balanced Poisson path, while some easy states remain slightly faster under Full-MIP. This is consistent
with the solver-routing interpretation developed in the static experiments: neural restriction is
most useful when the exact MIP is genuinely hard.

One nonhomogeneous-heavy path ends with one deferred vehicle under both controllers. Because both
methods produce the same outcome under the same committed state and arrival realization, this is not
a neural-pruning artifact.

## Important correction made during implementation

An earlier version of this commitment model treated residual slot indices as absolute slot numbers.
That incorrectly blocked suffix placement behind committed vehicles and produced artificial deferrals.
The implemented version instead treats residual slots as local suffix indices and appends them behind
the committed prefix. The final feasibility audit verifies that this corrected representation has
zero duplicate slots and zero discharge-order inversions.

## What is now ready

The dynamic computational architecture is now complete at prototype level:

    stochastic arrivals/cancellations
        -> uncommitted waiting pool
        -> fixed committed lane prefixes
        -> residual capacities
        -> hardness routing
        -> Full-MIP or adaptive NGFLO
        -> commitment update
        -> next decision epoch.

## Next stage

The next stage should be a **multi-seed publication experiment**, not another architectural rewrite.

Recommended expansion:
- seeds: at least 10 initially, then 20-30 for the final manuscript;
- horizons: 6-10 decision epochs;
- arrival intensity: low / medium / high;
- balanced / heavy / car-dense fleet compositions;
- Full-MIP, RH-MIP, and NGFLO comparisons;
- report final loaded vehicles, final deferrals, cumulative waiting, computation time,
  fallback frequency, and feasibility rate.

Only after this replicated experiment should Section 6's dynamic placeholders be replaced by final
tables and figures.
