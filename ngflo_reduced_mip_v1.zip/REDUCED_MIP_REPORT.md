# NGFLO Reduced-MIP Candidate Restriction Experiment v1

## Experiment

The held-out graph-context scorer was connected to the exact ordered-slot Full-MIP.
For each vehicle, only its Top-K predicted lane/deck positions were retained, with
K in {2, 4, 6, 8, 12}. All exact slot variables associated with non-retained
positions were fixed to zero. The remaining problem was solved as a valid reduced MIP.

The experiment contains all 9 held-out Gold Dataset v2 instances:
n = 20, 30, 40 across balanced, heavy, and car-dense regimes.

The certified full-MIP objective for each instance is used as the reference J*.

## Aggregate results

 K  instances  gap_pct_mean  gap_pct_median  gap_pct_max  runtime_mean  full_runtime_mean  speedup_median  speedup_mean  variable_retention_mean  deferred_mean
 2          9   8238.870348     4711.353610 23290.485239      0.316167            0.44914        3.240381      3.266097                 0.144354       3.444444
 4          9   1256.214465       12.771460 11204.678173      0.197352            0.44914        4.845034      4.262668                 0.288708       0.555556
 6          9      5.781998        5.485734    14.545002      0.225431            0.44914        2.992567      2.950222                 0.433062       0.000000
 8          9      2.760999        2.450199     8.335032      0.128100            0.44914        3.097378      3.213468                 0.577416       0.000000
12          9      0.854369        0.707710     2.447768      0.148889            0.44914        2.374360      2.773980                 0.788708       0.000000

## Quality thresholds

 K  instances  gap_le_0_1pct  gap_le_1pct  gap_le_3pct  no_deferral_instances  mean_variable_reduction_pct
 2          9              0            0            0                      3                    85.564588
 4          9              0            0            0                      8                    71.129177
 6          9              0            0            2                      9                    56.693765
 8          9              1            3            6                      9                    42.258353
12          9              1            6            9                      9                    21.129177

## Main finding

The first downstream optimization experiment materially changes the interpretation
of Recall@K.

At K=6, only about 43.3% of assignment
variables are retained, but the median objective gap is
5.49% and all nine instances load every vehicle.
Thus moderate exact-position Recall does not imply catastrophic optimization failure: the reduced
MIP can recover alternative feasible assignments.

At K=8, the mean retained fraction rises to
57.7% and the median gap falls to
2.45%.

At K=12, the median objective gap is
0.71% with no deferrals, but nearly
78.9% of assignment variables remain,
so the compression advantage is modest.

K=2 and K=4 are too aggressive. Several instances defer vehicles, and because deferral carries a
large penalty, percentage objective gaps can become extremely large. Those values should not be
interpreted as numerical instability; they indicate that candidate pruning removed enough useful
placements to force expensive deferrals.

## Runtime caution

On these small certified instances, the full MIP is already easy. Therefore runtime speedup is not
yet a reliable headline metric: model-construction and presolve overhead can dominate. The decisive
speed test must be repeated on n >= 50 hard instances where the unrestricted MIP is genuinely costly.

## Decision for the next stage

K=6 and K=8 form the most informative candidate range for further study:
- K=6 gives stronger compression but several-percent objective loss;
- K=8 gives a better quality/compression compromise;
- K=12 is a conservative fallback.

The next experiment should use adaptive K:
start at K=6, solve, and expand to K=8 or K=12 only when a quality/feasibility proxy indicates that
the restriction is too aggressive. This directly implements the adaptive-expansion mechanism in
Section 4 and Proposition 5 of Section 5.
