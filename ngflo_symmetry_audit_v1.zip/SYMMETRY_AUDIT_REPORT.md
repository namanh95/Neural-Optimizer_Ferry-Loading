# Symmetry / Alternative-Optimum Audit v1

A controlled forced-edge audit was performed on three held-out n=20 instances,
one from each fleet regime. For every vehicle, the certified Full-MIP assignment
and two alternative compatible lane/deck positions were tested by forcing the
vehicle to that position and re-solving.

A forced alternative is classified as **exact-equivalent** when a feasible solution
with the original certified objective value is found. Since the constrained optimum
cannot be below the original global optimum, finding the same objective certifies
that the forced edge belongs to at least one global optimum.

A forced alternative is classified as **near-optimal** when a feasible solution is
found within 0.1% of the original objective.

Results:
            instance_id  n congestion  audited_edges  vehicles_with_multiple_exact  vehicles_with_multiple_near  exact_equivalent_edges  near_optimal_edges
 small_balanced_n20_s33 20   balanced             60                             4                           16                      25                  51
small_car_dense_n20_s33 20  car_dense             60                             4                           19                      26                  58
    small_heavy_n20_s33 20      heavy             60                             4                           11                      26                  42

Across 60 vehicles, 12 vehicles had more than one
audited exact-optimal position, while 46 had more
than one audited near-optimal position.

This confirms that single-solution lane labels are materially non-unique in the current synthetic
benchmark. Exact-lane classification therefore penalizes some assignments that belong to another
optimal or near-optimal loading plan.
